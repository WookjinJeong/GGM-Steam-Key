#!/bin/sh
nohup npm start >/dev/null 2>&1 &